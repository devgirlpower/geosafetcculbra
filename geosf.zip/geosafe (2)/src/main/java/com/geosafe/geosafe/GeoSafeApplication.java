package com.geosafe.geosafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeoSafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeoSafeApplication.class, args);
	}

}
