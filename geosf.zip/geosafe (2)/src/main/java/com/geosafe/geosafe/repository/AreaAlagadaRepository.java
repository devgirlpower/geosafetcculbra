package com.geosafe.geosafe.repository;

import com.geosafe.geosafe.model.AreaAlagada;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AreaAlagadaRepository extends MongoRepository<AreaAlagada, String> {}
