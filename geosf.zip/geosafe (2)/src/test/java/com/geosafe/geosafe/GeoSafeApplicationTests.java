package com.geosafe.geosafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeoSafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
